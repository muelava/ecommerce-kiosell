function btnBurger(){
    // var title = document.querySelector("#title");
    // title.classList.toggle("d-none");

    // var nama = document.querySelector("#nama");
    // nama.classList.toggle("d-none");
    
    // var sebagai = document.querySelector("#sebagai");
    // sebagai.classList.toggle("d-none");

    // var imgProfile = document.querySelector("#img-profile");
    // imgProfile.classList.toggle("d-none");
 
    // var navigasi, i ;
    // navigasi = document.querySelectorAll("#navigasi");

    // for (i = 0; i < navigasi.length; i++) {
    //     navigasi[i].classList.toggle("d-none");
    // }


    // var imgProfile = document.querySelector(".sidebar");
    // imgProfile.classList.toggle("tampil");

}